No more cash wasted on energy crystals!
**No energy crystal purchase required**
**Works on current and new saves!**