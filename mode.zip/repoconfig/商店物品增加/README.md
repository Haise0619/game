InfusedGalaxy´s **MoreShopItems** Fork & Updated and It´s Code made Fully Open Source!

### Report bugs/Feature Requests

You can **open** a **new** "Issue" for those [here](https://github.com/Jettcodey/MoreShopItems/issues)