### v2.1.4
- Fixed an Issue preventing more than "5" Power Crystals to spawn.
- Fixed an Issue causing some Items to be spawned Stuck in the Wall.

### v2.1.3
- Mod is now able to **always** spawn two shelves in the Shop.
- Increased the itemAmounts (again)

### v2.1.2
- Added Pocket C.A.R.T. Shop spawn config
- Added C.A.R.T. Shop spawn config
- Added Tool Shop spawn config (Phase Bridge is currently the only tool)
- Added setting to log possible shop items on Shop level load
- "Max Additional Shelves In Shop" default is now 2, will try to spawn 2 shelves if possible

### v2.1.1
- Added new configuration entries for managing additional shelves and stackable items.
- Enhanced shelving unit spawning logic.
- Enhanced compatibility for "NikkiUpgrades" mod.
- Increased the itemAmounts

### v2.1.0
- Mod Fixed for Repo v2.1.0