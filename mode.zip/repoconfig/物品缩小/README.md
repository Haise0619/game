# ShrinkerCart

Bigger the item better the shrink!

物品越大，缩得越小。

(Forked from [oksamies' ShrinkerCart](https://github.com/oksamies/ShrinkerCart))

## Features

English:

1. Shrink when you put items into the cart.
2. Shrinker won't apply to mosters, C.A.R.T. Cannon and C.A.R.T. Laser. Enjoy!

Chinese:

1. 当你向购物车中放置物品时，物品会自动缩小。
2. 缩小功能不会对怪物、推车加农炮(Cannon)和推车激光枪(Laser)生效。

## Compiling

.NET Version: 9.0.302

Run this command to build:

```bash
dotnet build .\ShrinkerCartPlus.csproj
```

Output will be at: `./plugins/Rise-ShrinkerCartPlus/ShrinkerCartPlus.dll`