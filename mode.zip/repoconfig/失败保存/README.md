# ResetFailedSave
Keep the archive to continue when the game fails.

游戏失败时保留存档继续。

