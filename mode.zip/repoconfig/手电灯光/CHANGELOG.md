# v1.0.2
- Fixed issues with spelling. 
- New Default Brightness is level 3. 
- Added Better Details to ReadME.

# v1.0.1
- Fixed Dependencies 

# v1.0.0 
- Initial release Hello World