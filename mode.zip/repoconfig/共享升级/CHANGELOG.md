# Changelog

All notable changes to this project will be documented in this file.

## [2.1.3] - 2025-04-03
### Fixed
- Fixed issue where other players couldn't join (thanks to Binnes for helping with testing).
- Fixed targeting of the wrong BepInEx version.

### Known Issue
- Discovered bug: Upgrades are not immediately applied at the start of a level. For example, if a player takes 3 Stamina upgrades at the beginning of a level, everyone receives those upgrades, but the changes won't be visible until a level change occurs. This will be fixed in a future update.

## [2.1.0] - 2025-04-02
### Added
- Forced synchronization on every level change.
### Fixed
- Bug that synchronized old upgrades after losing the game.

## [2.0.1] - 2025-04-01
### Added
- Updated README.md

## [2.0.0] - 2025-04-01
### Changed
- **Complete Redesign:** The mod has been entirely reworked.
- **Upgrades Synchronization:** Upgrades are now synchronized for all players rather than patching each upgrade method individually.
- **Improved Stability:** The new synchronization system greatly reduces synchronization bugs. Only the host of the game needs the mod installed.
- **Modded Upgrades Support:** Enhanced support for modded upgrades, ensuring they are handled seamlessly.

## [1.0.1] - 2025-03-18
### Added
- Updated README.md

## [1.0.0] - 2025-03-15
### Added
- Initial release
