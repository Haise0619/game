# Description
A mod that allows team-wide effects from upgrade items and health packs. Only the host needs to install it.

## Changelog
    - v1.1.0
        - Removed Health Pack Heal Multiplier - This feature is rarely used, and only works client-side. Removing as it is not really in scope with this project, and causes more issues than it solves
        - Fixed Health Pack Heal duplication when non-host players use health packs
        - Fixed network crash on Level Change from Arena to Lobby Menu caused by synchronization spam
    - v1.0.2
        - Reverted mod logic back to original, only applies upgrades on level change
    - v1.0.1
        - Attempted to rework upgrades to apply immediately rather than level change, this introduced a major disconnect bug
    - 1.0.0
        - Initial Release