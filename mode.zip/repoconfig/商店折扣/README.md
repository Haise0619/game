# HumanizedShop
Shop gets random discounts and get free items based on probability

商店获取随机折扣，并按概率免费获得商品

## Configuration
- **Enable**: Whether the shop gets random discounts.
- **Probability**: Probability of free goods.
## Note
| Discounts  | Probability |
| :--------: | :---------: |
| [0.9, 0.8) |     3%      |
| [0.8, 0.7) |     7%      |
| [0.7, 0.6) |     15%     |
| [0.6, 0.2) |     30%     |
|  [0.2, 0]  |     45%     |

