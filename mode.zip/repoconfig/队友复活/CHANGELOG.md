# v1.2.0
* Changed revive health from 20hp to 20% of max health
* Fixed over-healing (hopefully)
* Fixed revived players getting stuck in the map (hopefully)
* Added logging

# v1.1.0
* Initial release
