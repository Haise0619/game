## Revive Head in Truck or Extraction Point
Allows players to be revived at any point in the level, by placing their head inside the truck or any open extraction point.

Players revive with 20% of their maximum health.
