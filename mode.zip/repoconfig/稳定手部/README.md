# R.E.P.O. - High Strength Fix

When players have a very high strength level, grabbing light objects causes them to shake/wobble a lot.
This is mostly an issue for gun items, but also affects valuables.

This mod fixes that.

## Installation
1. Download & install [BepInEx](https://github.com/BepInEx/BepInEx).
2. Download the [latest release](https://gitlab.com/rozza_mods/repo-highstrengthfix/-/releases) of this mod.
3. Place `REPO_HighStrengthFix.dll` in your `BepInEx/plugins` directory.

Alternatively, the mod is available via the [Thunderstore Mod Manager](https://thunderstore.io/c/repo/p/Rozza/HighStrengthFix/).

## Screenshots
### Vanilla/mod disabled (strength level 10)
![Mod Disabled](https://gitlab.com/rozza_mods/repo-highstrengthfix/-/raw/main/images/ModDisabled.gif "Mod Disabled")
### Mod enabled (strength level 10)
![Mod Enabled](https://gitlab.com/rozza_mods/repo-highstrengthfix/-/raw/main/images/ModEnabled.gif "Mod Enabled")

## How it works

The mod calculates a strength "cap" based on the item's mass (`(mass * CapMultiplier) + CapOffset`) - the heavier the item, the higher the cap.
If your strength is lower than the cap, the mod does nothing.

If your strength is higher than the cap, it calculates a damping factor to apply to the grab that brings your effective strength down to the cap.
It should have no impact on what you can pick up.

I found the sledgehammer to still not want to play nicely with this system at high strength levels, so for heavy melee weapons a (configurable) set cap
is used.

## Configuration

All options can be configured in-game using the [REPOConfig mod](https://thunderstore.io/c/repo/p/nickklmao/REPOConfig/), or manually by:

1. Launch the game with mod installed at least once.
2. Edit the `REPO_HighStrengthFix.cfg` file within your `BepInEx/config` directory.

<details>
<summary>Example Configuration</summary>

```
## Settings file was created by plugin HighStrengthFix v1.0.0
## Plugin GUID: REPO_HighStrengthFix

[General]

# Setting type: Boolean
# Default value: true
EnableMod = true

# Setting type: Single
# Default value: 1.95
# Acceptable value range: From 1 to 2.5
CapMultiplier = 1.95

# Setting type: Single
# Default value: 0.1
# Acceptable value range: From 0 to 1.99
CapOffset = 0.1

## Lower cap for heavy melee weapons (sledgehammer)
# Setting type: Boolean
# Default value: true
LowerCapForHeavyMelee = true

## The cap to use for heavy melee
# Setting type: Single
# Default value: 2.1
# Acceptable value range: From 1 to 3
HeavyMeleeCap = 2.1


```

</details>